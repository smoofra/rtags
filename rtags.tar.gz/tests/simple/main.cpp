void foo()
{

}

int main()
{
    foo();
}
