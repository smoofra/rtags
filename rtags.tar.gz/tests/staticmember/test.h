#ifndef TEST_H
#define TEST_H

#include <string>

class TestClass
{
public:
    static int someFunction(const std::string &ting);
    static bool someOtherFunction(int hepp);
};

#endif
