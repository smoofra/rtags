#ifndef c_h
#define c_h

class C
{
public:
    C(int v);
    C *func() const;

    int mem;
};

#endif
